import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

// Simple SVG Graph Component
const WaveformGraph = ({ data }) => {
  if (!data || data.length === 0) return <div className="no-data">No Signal Data</div>;

  const displayData = data.length > 2000 ? data.filter((_, i) => i % 5 === 0) : data;
  
  const height = 150;
  const width = 600;
  const max = Math.max(...displayData);
  const min = Math.min(...displayData);
  const range = max - min || 1;

  const points = displayData.map((val, index) => {
    const x = (index / (displayData.length - 1)) * width;
    const normalizedY = (val - min) / range;
    const y = height - (normalizedY * height);
    return `${x},${y}`;
  }).join(' ');

  return (
    <div className="graph-container">
      <h4>ECG Waveform Visualization</h4>
      <svg viewBox={`0 0 ${width} ${height}`} className="waveform-svg">
        <polyline fill="none" stroke="#2563eb" strokeWidth="2" points={points} />
      </svg>
    </div>
  );
};

function App() {
  const [activeTab, setActiveTab] = useState('apnea'); // 'apnea' or 'diabetes'
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  const onFileChange = (e) => {
    setFiles(Array.from(e.target.files));
    setResult(null);
    setError('');
  };

  const handleAnalyze = async () => {
    if (files.length === 0) {
      setError("Please select both .hea and .dat files");
      return;
    }

    setLoading(true);
    setError('');

    const formData = new FormData();
    files.forEach(file => {
      formData.append('files', file);
    });

    try {
      const res = await axios.post(
        `http://localhost:5000/api/predict?modelType=${activeTab}`, 
        formData, 
        { headers: { 'Content-Type': 'multipart/form-data' } }
      );

      if (res.data.success === false) {
        throw new Error(res.data.error || "Analysis Failed");
      }

      console.log("🔍 Backend Response:", res.data);
      setResult(res.data);
    } catch (err) {
      setError(err.response?.data?.error || "Connection Failed. Check Node Server.");
    } finally {
      setLoading(false);
    }
  };

  // --- ROBUST RENDER FUNCTION (Autodetects Model) ---
  const renderAnalysisResults = () => {
    const prediction = result.prediction || {};
    
    // 🔍 AUTO-DETECT LOGIC: Trust the data, not the tab
    const isDiabetesData = prediction.hasOwnProperty('has_diabetes');
    
    let isPositive = false;
    let diagnosisTitle = "Normal";
    let modelLabel = "";

    if (isDiabetesData) {
        // --- DIABETES MODE (Forced by Data) ---
        modelLabel = "Diabetes";
        // Check the flag from your screenshot
        isPositive = prediction.has_diabetes === true; 
        diagnosisTitle = isPositive ? "Diabetes Risk Detected" : "Low Risk (Normal)";
    } else {
        // --- APNEA MODE ---
        modelLabel = "Apnea";
        isPositive = prediction.has_apnea === true;
        diagnosisTitle = isPositive ? "Positive for Apnea" : "Negative (Normal)";
    }

    // Force Red (danger) if positive, Green (success) if negative
    const diagColor = isPositive ? "danger" : "success";
    
    // Handle demographics formatting
    let demographicsList = [];
    if (result.demographics) {
      if (Array.isArray(result.demographics)) {
        demographicsList = result.demographics;
      } else {
        demographicsList = Object.entries(result.demographics).map(
          ([key, value]) => `${key}: ${value}`
        );
      }
    }
    
    if (demographicsList.length === 0) {
      demographicsList = ["No demographics data found"];
    }

    return (
      <div className="results-panel">
        <div className={`diagnosis-card bg-${diagColor}`}>
          <h3>{modelLabel} Diagnosis Result</h3>
          <h1>{diagnosisTitle}</h1>
          
          {prediction.probability !== undefined && (
            <p>Confidence: {(prediction.probability * 100).toFixed(1)}%</p>
          )}
          
          {prediction.risk_level && (
            <p style={{fontSize: '1.1rem', marginTop: '10px', opacity: 0.9}}>
              Risk Level: {prediction.risk_level}
            </p>
          )}
        </div>

        <div className="info-card">
          <h3>Patient Demographics</h3>
          <ul className="demographics-list">
            {demographicsList.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </div>

        {result.waveform && (
          <div className="info-card">
            <h3>ECG Waveform</h3>
            <div className="graph-container">
              <svg viewBox="0 0 800 100" className="waveform-svg">
                <polyline 
                  fill="none" 
                  stroke="#2563eb" 
                  strokeWidth="1.5" 
                  points={result.waveform} 
                />
              </svg>
            </div>
          </div>
        )}

        {/* Debug Info */}
        {process.env.NODE_ENV === 'development' && (
          <div className="info-card" style={{background: '#f0f9ff', border: '1px solid #bae6fd'}}>
            <h3>🔍 Debug Info</h3>
            <pre style={{fontSize: '0.75rem', overflow: 'auto'}}>
              {JSON.stringify(prediction, null, 2)}
            </pre>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="app-container">
      <header>
        <h1>ESI Medical Analysis</h1>
        <div className="tabs">
          <button 
            className={activeTab === 'apnea' ? 'active' : ''} 
            onClick={() => {setActiveTab('apnea'); setResult(null); setFiles([]);}}
          >
            Apnea Detection
          </button>
          <button 
            className={activeTab === 'diabetes' ? 'active' : ''} 
            onClick={() => {setActiveTab('diabetes'); setResult(null); setFiles([]);}}
          >
            Diabetes Detection
          </button>
        </div>
      </header>

      <main>
        {!result && (
          <div className="upload-section">
            <div className="drop-zone">
              <p>Select <strong>.hea</strong> and <strong>.dat</strong> files</p>
              <input 
                type="file" 
                multiple 
                accept=".hea,.dat" 
                onChange={onFileChange} 
              />
              <div className="file-list">
                {files.map((f, i) => <div key={i} className="file-tag">{f.name}</div>)}
              </div>
            </div>
            
            <button 
              className="analyze-btn" 
              onClick={handleAnalyze}
              disabled={loading || files.length === 0}
            >
              {loading ? "Processing..." : `Analyze for ${activeTab}`}
            </button>
          </div>
        )}

        {error && <div className="error-msg">{error}</div>}

        {result && (
          <div className="results-container">
            {/* 🔴 IMPORTANT: This is the part likely missing in your previous file 🔴 */}
            {renderAnalysisResults()}
            
            <button className="reset-btn" onClick={() => {setResult(null); setFiles([]);}}>
              Analyze Another Patient
            </button>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;